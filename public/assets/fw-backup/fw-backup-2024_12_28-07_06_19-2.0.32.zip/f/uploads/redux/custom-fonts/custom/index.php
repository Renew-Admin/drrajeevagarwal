<?php
//Silence is golden
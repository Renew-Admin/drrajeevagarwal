<?php
 //silence is golden